<?php

$list_file = scandir("./214");


// foreach ($list_file as $key => $value) {
//     $arrName = explode(".", $value);
//     $newName = hex2bin($arrName[0]) . ".gif";
//     rename("./214/$value", "./214/$newName");
// }

// echo "done";

echo "<script type=\"script/javascript\">
'二'.charCodeAt(i).toString(16);
</script>";
